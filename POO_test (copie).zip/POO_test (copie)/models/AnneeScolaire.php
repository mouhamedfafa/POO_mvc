<?php
namespace App\Model;
use App\Core\Model;
class AnneeScolaire extends Model {
   // fonctions navigationnels



   //OneToMany 
   public function inscriptions():array{
    return [];
    }
     
}