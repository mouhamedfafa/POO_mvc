<?php
namespace App\controller;

use App\Core\Controller;
use App\Core\Request;
class ClasseController extends Controller{

    
    public function listerClasse(){

    }
     public function creerClasse(){
        
    }
    
}