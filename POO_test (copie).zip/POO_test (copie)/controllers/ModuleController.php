<?php
namespace App\Controller;
use App\Core\Controller;
class ProfesseurController extends Controller{

    public function affecterModule(){

    }

}