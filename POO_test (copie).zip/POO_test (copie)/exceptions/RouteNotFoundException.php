<?php
namespace App\Exception;

class RouteNotFoundException extends \Exception{
    public $message="Page not found , erreur 404";
}